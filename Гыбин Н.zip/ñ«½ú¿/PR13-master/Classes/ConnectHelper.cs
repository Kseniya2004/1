﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR13.Classes
{
    class ConnectHelper
    {
        public static List<PRICE> pricies = new List<PRICE>();
    }
}
