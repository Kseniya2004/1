﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Немтырёвой Ксении, 1 вариант");
            Console.WriteLine("Дана строка, состоящая из групп нулей и единиц. Посчитать количество нулей и единиц.");
            String stroka = Console.ReadLine();
            int zero = 0;
            int one = 0;
            foreach(char c in stroka)
            {
                if (c == 48)//48 - код цифры 0
                {
                    zero++;
                }
                else if (c == 49)//49 - код цифры 1
                {
                    one++;
                }
            }
            Console.WriteLine($"Количество нулей: {zero}, Количество единиц: {one}");
            Console.ReadKey();
        }
    }
}
